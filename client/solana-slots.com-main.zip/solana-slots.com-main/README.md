This is a crypto casino, solana slot machine built with nodejs, quicknode api, mongodb. Secrets are kept in .env file. 
Have fun gambling! 
